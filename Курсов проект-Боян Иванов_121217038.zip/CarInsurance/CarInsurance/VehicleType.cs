﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInsurance
{
    public enum VehicleType
    {
        Bike = 0,
        Car,
        Bus,
        Truck
    };

    public enum CoupeType
    {
        Sedan = 0,
        Coupe,
        Cabriolet,
        Combi,
        Hatchback,
        Minivan,
        Van,
        Invalid
    }

}
